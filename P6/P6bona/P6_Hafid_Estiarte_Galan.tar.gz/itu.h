#ifndef ITU_H
#define ITU_H

#include "codif.h"

extern morse_table_t itu_table;
void itu_init(void);


#endif
